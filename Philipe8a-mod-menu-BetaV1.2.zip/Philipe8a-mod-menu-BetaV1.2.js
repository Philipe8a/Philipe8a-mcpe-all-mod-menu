print ('Welcome To philipe8a mod')
print ('Made By philipe8a')
print ('Enjoy All The Update by philipe8a')
print ('New BIG UPDATE!!!')
print ('Philipe8a BetaV1.2')
print ('Mod Menu Open...')
print ('90%')
print ('100%')
print ("YOUTUBE/CHANNEL: YOUTUBE/PHILIPE8A") 

//<>--------------------<><>--------------------<><>--------------------<>
//Main Maker philipe8a
//Made by philipe8a [©Copyright 2020 All rights reserved.]
//Create by Philipe8a
//Thank You                                                                                  
//philipe8a                                                                                    
//<>--------------------<><>--------------------<><>--------------------<>
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
var Button = android.widget.Button;
var LinearLayout = android.widget.LinearLayout;
var RelativeLayout = android.widget.RelativeLayout;
var PopupWindow = android.widget.PopupWindow;
var ScrollView = android.widget.ScrollView;
var TextView = android.widget.TextView;
var CheckBox = android.widget.CheckBox;
var Switch = android.widget.Switch;
var Toast = android.widget.Toast;
var Runnable = java.lang.Runnable;
var View = android.view.View;
var ColorDrawable = android.graphics.drawable.ColorDrawable;
var Color = android.graphics.Color;
var Gravity = android.view.Gravity;
var Intent = android.content.Intent;
var Uri = android.net.Uri;

//MORE GUI + VARIABLES
var player1 =  Player.getName(Player.getEntity())
var Color2 = new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(140,140,0,140)); 
var Color1 = new android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(140,140,140,140)); 
var GUI;
      var menu;
      var exitUI;
      
      
      var VERSION = "[BETAV1.2]";
var NAME = "Philipe8a mod menu BETAV1.2";
var DEVELOPERS = "Philipe8a";

//MODULE VARIABLES

var aim;
var aimbot = false;
var aimed = false;

var grapples
var grappless = false;
var grappleed = false;

var BtnOn = true;
var flyon = false;
var sethome;
var instantkill = false;
var instantbreak = false;
var unlimitedArrow = false;
var bd = false;
var defaultDestroyTime = [
null, 1.5, 0.6, 0.5, 2, 2, 0, -1, null, null, null, null, 0.5, 0.6, 3, 3, 3, 2, 0.2, 0.6, 0.3, 3, 3, null, 0.8, null, 0.2, 0.7, null, null, 4, 0, 0, null, null, 0.8, null, 0, 0, 0, 0, 3, 5, 2, 2, 2, 0, 1.5, 2, 50, 0, 0, null, 2, 2.5, null, 3, 5, 2.5, 0, 0.6, 3.5, 3.5, 1, 3, 0.4, 0.7, 2, 1, null, null, 5, null, 3, 3, null, null, null, 0.1, 0.5, 0.2, 0.4, 0.6, 0, null, 2, 1, 0.4, 0.3, null, 1, 0.5, null, null, -1, 3, null, 1.5, null, null, 5, 0.3, 1, 0, 0, null, 2, 2, 1.5, null, null, 2, null, 2, null, null, null, null, null, null, null, null, null, null, null, null, null, 0.8, null, null, null, null, null, 2, 2, 2, null, null, 2, null, 0, 0, null, null, null, null, null, null, null, null, null, null, null, null, 0.8, 0.8, 2, 2, null, null, null, null, null, null, null, null, null, null, null, 0.5, 0.1, 5, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 0, 3.5, 50, 5, 0.6, 0.6, 5, null, null, null, null, 0
]

      function dip2px(dips){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      return Math.ceil(dips * ctx.getResources().getDisplayMetrics().density);
      }
      function newLevel(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var layout = new android.widget.LinearLayout(ctx);
      layout.setOrientation(1);
      var menuBtn = new android.widget.Button(ctx);
      menuBtn.setText('Philipe8a mod menu>3');
      menuBtn.setTextSize(15)
      menuBtn.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      mainMenu();
      clientMessage("§o§aWelcome "+player1+" to Philipe8a mod menu BetaV1.2")
      exit();
      }
      }));
      layout.addView(menuBtn);
      GUI = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
      GUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.BLUE));
      GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 10, 20);
      }catch(err){
      print('An error occured: ' + err);
      }
      }}));
      }
       function mainMenu(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
      
      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(15);
      textview.setText('Welcome '+player1+'!');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(15);
      textview.setText('<=Mod menu philipe8a BetaV1.2=>');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      
      var scrollText = new android.widget.TextView(ctx);
scrollText.setText("WELCOME TO PHILIPE8A MOD MENU VBeta1.2 Menu");
scrollText.setTextSize(15);         
scrollText.setTextColor(android.graphics.Color.CYAN);    
 scrollText.setGravity(android.view.Gravity.CENTER);
scrollText.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
scrollText.setMarqueeRepeatLimit(-2);
scrollText.setSingleLine();
scrollText.setHorizontallyScrolling(true);
scrollText.setSelected(true);
menuLayout.addView (scrollText);
      
      var button = new android.widget.Button(ctx);
      button.setText('Exit');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu.dismiss();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Main Mods');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(25)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      mainHax();
      menu.dismiss();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Weapons');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(25)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      giveMenu();
      menu.dismiss();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Message Menu');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(25)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      msMenu();
      menu.dismiss();
      }
      }));
      menuLayout.addView(button);
      
    var button = new android.widget.Button(ctx);
      button.setText('Fov Menu');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(25)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      fovMenu();
      menu.dismiss();
      }
      }));
      menuLayout.addView(button); 
      
var button = new android.widget.Button(ctx);
      button.setText("Other Menu 1");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(25)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      otherMenu();
      menu.dismiss();
      }
      }));
      menuLayout.addView(button); 
      
var button = new android.widget.Button(ctx);
      button.setText("Infection Menu");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(25)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      infMenu();
      menu.dismiss();
      }
      }));
      menuLayout.addView(button); 
      

      var button = new android.widget.Button(ctx);
      button.setText("Xp Menu");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(25)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      playerMenu();
      menu.dismiss();
      }
      }));
      menuLayout.addView(button);
      
  
      
      //More buttons...
      menu = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/3.5, ctx.getWindowManager().getDefaultDisplay().getHeight());
      menu.setBackgroundDrawable(Color2);
      menu.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }

function infMenu(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('DOWNLOAD Menu');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);

var button = new android.widget.Button(ctx);
      button.setText("Exit");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menur.dismiss();
      mainMenu();
      
      }
      }));
      menuLayout.addView(button);

var button = new android.widget.Button(ctx);
      button.setText("📥Download📥");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(25)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      infect0();
     
      }
      }));
      menuLayout.addView(button);



function infect0(){
new android.os.Handler().postDelayed(new java.lang.Runnable({run:function()
{
clientMessage("§6§a DOWNLOADING 20% please wait...");
      infect1();
}
}),1000);
}

function infect1(){
new android.os.Handler().postDelayed(new java.lang.Runnable({run:function()
{
      clientMessage("§7§d DOWNLOADING 40% please wait...");
      infect2();
}
}),1000);
}


function infect2(){
new android.os.Handler().postDelayed(new java.lang.Runnable({run:function()
{
      clientMessage("§8§c DOWNLOADING 80% please wait...");
      infect3();
}
}),1000);
}


function infect3(){
new android.os.Handler().postDelayed(new java.lang.Runnable({run:function()
{
      clientMessage("§9§e DOWNLOADING 90% please wait...");
      infect4();
}
}),1000);
}


function infect4(){

new android.os.Handler().postDelayed(new java.lang.Runnable({run:function()
{
      clientMessage("§1§9 DOWNLOADING 100% please wait...");
      infect5();
}
}),1000);
}



function infect5(){

new android.os.Handler().postDelayed(new java.lang.Runnable({run:function()
{
      clientMessage("§2DOWNLOADING SUCCESSFUL All players given §9Co-§dHost");
      Server.sendChat("§6§oClick The 'Philipe8a mod menu>3' button at your screen")
}
}),1000);
}      


      menur = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/3.5, ctx.getWindowManager().getDefaultDisplay().getHeight());
      menur.setBackgroundDrawable(Color2);
      menur.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }

      function otherMenu(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
      
var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('More Option Menu');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);

var button = new android.widget.Button(ctx);
      button.setText("Exit");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menua.dismiss();
      mainMenu();
      
      }
      }));
      menuLayout.addView(button);

var button = new android.widget.Button(ctx);
      button.setText("More Option Menu");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menua.dismiss();
      gta5();
    
      
      }
      }));
      menuLayout.addView(button);





      //More buttons...
      menua = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/3.5, ctx.getWindowManager().getDefaultDisplay().getHeight());
      menua.setBackgroundDrawable(Color2);
      menua.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }

function gta5(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
     
var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('More Option Menu');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);

var textview = new android.widget.TextView(ctx);
      textview.setTextSize(20);
      textview.setText('More Option Menu');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);


var button = new android.widget.Button(ctx);
      button.setText("Exit");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      gta.dismiss();
      mainMenu();
      
      }
      }));
      menuLayout.addView(button);
      

var button = new android.widget.Button(ctx);
      button.setText('Set Full Health');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){

Player.setHealth(20);
clientMessage("§dYou Now Have {Full Health}");

      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Set Full Hunger');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){

 Player.setHunger(25);
clientMessage("§dYou Now Have {Full Hunger}");

      }
      }));
    menuLayout.addView(button);

      var button = new android.widget.Button(ctx);
   
      var button = new android.widget.Button(ctx);
      button.setText('Fly On');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){ 

Player.setCanFly(1);
clientMessage("§dFly Mode {ON}");

      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Fly Off');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
        

Player.setCanFly(0);
clientMessage("§dFly Mode {OFF}");

 
     }
      }));  
    menuLayout.addView(button);

      var button = new android.widget.Button(ctx);
   
      var button = new android.widget.Button(ctx);
      button.setText('God Mode');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){

Player.setHealth(9999);
clientMessage("§dYou Now Have GodMode 9999");


        
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Set Time DAY');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
        
Level.setTime(0);
clientMessage("§dTime Set {DAY}");


      }
      }));

    menuLayout.addView(button );

      var button = new android.widget.Button(ctx);
   
      var button = new android.widget.Button(ctx);
      button.setText('Set Time NIGHT');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
  
Level.setTime(18000);
clientMessage("§dTime Set {NIGHT}");

      }
      }));
      menuLayout.addView(button);
       
       var button = new android.widget.Button(ctx);
      button.setText('Unlimited Hunger');
button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.setHunger(999999999999999999999999999)    
       
      }
      }));
      
        menuLayout.addView(button);
        
        var button = new android.widget.Button(ctx);
      button.setText('Kill You');
button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.setHealth(0)
      
         
      
      
      
      }
      }));
      
      
         menuLayout.addView(button);

var button = new android.widget.Button(ctx);
      button.setText('Lite Boost');
button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      setVelX( getPlayerEnt(), 3)	
    
            
      }
      }));
      
     menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Heavy Boost');
button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      setVelX( getPlayerEnt(), 7)
    
            
      }
      }));
      
     menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Lite Boost');
button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      setVelX( getPlayerEnt(), 3)	
    
            
      }
      }));
      
     menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Build Home');
button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      homeX = Player.getX();
              homeY = Player.getY()+2;
              homeZ = Player.getZ();
              sethome = 1;
    
            
      }
      }));
      
     menuLayout.addView(button);
     
     var button = new android.widget.Button(ctx);
      button.setText('Slow Motion On');
button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setGameSpeed(6);
    
            
      }
      }));
      
     menuLayout.addView(button);
     
     var button = new android.widget.Button(ctx);
      button.setText('Slow Motion Off');
button.setTextColor(android.graphics.Color.CYAN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setGameSpeed(20);
    
            
      }
      }));
      
     menuLayout.addView(button);
      



      //More buttons...
      gta = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/3.5, ctx.getWindowManager().getDefaultDisplay().getHeight()/2);
      gta.setBackgroundDrawable(Color1);
      gta.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.CENTER, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }


      
          function playerMenu(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('Xp Menu');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var button = new android.widget.Button(ctx);
      button.setText("Exit");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu0.dismiss();
      mainMenu();
      
      }
      }));
      menuLayout.addView(button);
      var button = new android.widget.Button(ctx);
      button.setText("200k Xp");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addExp(200000)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("300k Xp");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addExp(300000)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("400k Xp");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addExp(400000)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("500k Xp");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addExp(500000)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("600k Xp");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addExp(600000)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("700k Xp");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addExp(700000)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("800k Xp");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addExp(800000)
      }
      }));
      menuLayout.addView(button);
      
      
      var button = new android.widget.Button(ctx);
      button.setText("900k Xp");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addExp(900000)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("1M Xp");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addExp(1000000)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("Special Xp 999 BILLION");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addExp(9999999999999)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("ULIMITED XP SUPER SPECIAL");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addExp(999999999999999999)
      }
      }));
      menuLayout.addView(button);
     
     
      //More buttons...
      menu0 = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/3.5, ctx.getWindowManager().getDefaultDisplay().getHeight());
     menu0.setBackgroundDrawable(Color2);
      menu0.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.CENTER | android.view.Gravity.TOP, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }      
      
      function mainHax(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('Main Mods');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);

      
      var button = new android.widget.Button(ctx);
      button.setText('Exit');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu2.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Survival');               button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Level.setGameMode(0)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Creative');                 button.setTextColor(android.graphics.Color.BLACK);               button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Level.setGameMode(1)
      }
      }));
      menuLayout.addView(button);
      
     var button = new android.widget.Button(ctx);
      button.setText('Fly On');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.setCanFly(1)
      clientMessage('§LFly Mode  §3[Set]')     
      
      }
      }));
       
      
      
      menuLayout.addView(button);

var button = new android.widget.Button(ctx);
      button.setText('Fly Off');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Level.setGameMode(1)
      clientMessage('§LFly Mode §3[OFF]')      
      
      }
      }));            
     
     menuLayout.addView(button);
     
     var button = new android.widget.Button(ctx);
      button.setText('Instant Mine');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Entity.addEffect(Player.getEntity(),MobEffect.digSpeed,999999,200,false,false);      
            
      }
      }));      
     
     menuLayout.addView(button);    
       
      var button = new android.widget.Button(ctx);
      button.setText('No-Clip');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Entity.setCollisionSize(getPlayerEnt(), 0.0, 0.0);
      
      
      Player.setCanFly(1)
               
      }
      }));
      
     menuLayout.addView(button);

var button = new android.widget.Button(ctx);
      button.setText('No-Clip Off');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      
      Entity.setCollisionSize(getPlayerEnt(), 1, 2);
      
      Player.setCanFly(0)
                     
      }
      }));      
       
      menuLayout.addView(button);
      
       var button = new android.widget.Button(ctx);
      button.setText('Pause');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setGameSpeed(0)
            
      }
      }));
      
     menuLayout.addView(button);
     
      var button = new android.widget.Button(ctx);
      button.setText('Resume');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setGameSpeed(20)
            
      }
      }));
      
     menuLayout.addView(button);
         
        var button = new android.widget.Button(ctx);
      button.setText('Teleport To Sky');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      
       setVelY(Player.getEntity(), 6)
clientMessage("§aWeeeeeeeeeeeeeeeeeeeeeeeeee HELP ME AM IN THE SKY !!!!!!");
      
      }
      })); 
      
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Invisible');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Entity.addEffect(Player.getEntity(), MobEffect.invisibility, 999999, 2, false, false);
           
      }
      }));     
      
      menuLayout.addView(button);

var button = new android.widget.Button(ctx);
      button.setText('Ivisible Off');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Entity.removeAllEffects(getPlayerEnt()); 
        
      }
      }));
           
       menuLayout.addView(button);
      
     var button = new android.widget.Button(ctx);
   
      var button = new android.widget.Button(ctx);
      button.setText('God Mode');
      button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){

Player.setHealth(9999);

        
      }
      }));
      menuLayout.addView(button);
  
       var button = new android.widget.Button(ctx);
   
      var button = new android.widget.Button(ctx);
      button.setText('Super Speed 3000');
      button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){

ModPE.setGameSpeed(3000)
        
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
   
      var button = new android.widget.Button(ctx);
      button.setText('Normal Speed 20');
      button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){

ModPE.setGameSpeed(20)
       
      }
      }));
      menuLayout.addView(button);
       
      var button = new android.widget.Button(ctx);
      button.setText('Nuke');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      
            explode(getPlayerX(),getPlayerY(),getPlayerZ(),35);
     
      clientMessage('§LNUKE!!!!')               
      
      }
      }));       
            
       menuLayout.addView(button);
         
         var button = new android.widget.Button(ctx);
      button.setText('Ghost');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Entity.setCollisionSize(getPlayerEnt(), 0.0, 0.0);      
      
      }
      }));
      
      menuLayout.addView(button);

var button = new android.widget.Button(ctx);
      button.setText('Ghost Off');
button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Entity.setCollisionSize(getPlayerEnt(), 1, 2);      
            
      }
      }));
            
      menuLayout.addView(button);                   
      
      var button = new android.widget.Button(ctx);
      button.setText('Skyjump');
      button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
        setVelY(Player.getEntity(), 0.6)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Launch');
      button.setTextColor(android.graphics.Color.BLACK);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
        setVelY(Player.getEntity(), 6)
      }
      }));
      menuLayout.addView(button);
      
      var aim = new android.widget.Switch(ctx);
     
 aim.setText("AimBot");
      aim.setTextColor(android.graphics.Color.BLACK);
      aim.setPadding(10, 1, 1, 1);
      aim.setTextSize(15);
      aim.setChecked(aimed);
      aim.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener({
      onCheckedChanged: function(){
      if(!aimed){
      aimbot = true;
      aimed = true;
      }else{
      aimbot = false;
      aimed = false;
      }
      aim.setChecked(aimed);
      }
      }));
      menuLayout.addView(aim);
      
      var grapples = new Switch(ctx);
      grapples.setText("TpAura(buggy)");
      grapples.setTextColor(android.graphics.Color.BLACK);
      grapples.setPadding(10, 3, 3, 3);
      grapples.setTextSize(15);
      grapples.setChecked(grappleed);
      grapples.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener({
      onCheckedChanged: function(){
      if(!grappleed){
      grappless = true;
      grappleed = true;
      clientMessage('TpAura on')
      }else{
      grappless = false;
      grappled = false;
      }
      grapples.setChecked(grappleed);
      }
      }));
      menuLayout.addView(grapples);
      
      
      
      
      
      
      //More buttons...
      menu2 = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/3.5, ctx.getWindowManager().getDefaultDisplay().getHeight());
      menu2.setBackgroundDrawable(Color2);
      menu2.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.CENTER, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }
      
       function giveMenu(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('🔰Weapon Menu🔰');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);

      
      var button = new android.widget.Button(ctx);
      button.setText('Exit');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu4.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Diamond Tools');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addItemInventory(276, 1, 0);
      Player.addItemInventory(277, 1, 0);
      Player.addItemInventory(278, 1, 0);
      Player.addItemInventory(279, 1, 0);
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Iron Tools');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addItemInventory(256, 1, 0);
      Player.addItemInventory(257, 1, 0);
      Player.addItemInventory(258, 1, 0);
      Player.addItemInventory(267, 1, 0);
      
      }
      }));
      menuLayout.addView(button);
      
          var button = new android.widget.Button(ctx);
      button.setText('Gold Tools');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addItemInventory(283, 1, 0);
      Player.addItemInventory(284, 1, 0);
      Player.addItemInventory(285, 1, 0);
      Player.addItemInventory(286, 1, 0);
      }
      }));
      menuLayout.addView(button);       
      
     var button = new android.widget.Button(ctx);
      button.setText('Diamond Armor');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.setArmorSlot (0,310,0);
      Player.setArmorSlot (1,311,0);
      Player.setArmorSlot (2,312,0);
      Player.setArmorSlot (3,313,0);
      }
      }));
      menuLayout.addView(button); 
      
       var button = new android.widget.Button(ctx);
      button.setText('Gold Armor');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.setArmorSlot (0,314,0);
      Player.setArmorSlot (1,315,0);
      Player.setArmorSlot (2,316,0);
      Player.setArmorSlot (3,317,0);
      }
      }));
      menuLayout.addView(button); 
      
      var button = new android.widget.Button(ctx);
      button.setText('Diamonds dropped');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      var x = Player.getPointedBlockX();
	var y = Player.getPointedBlockY()+1;
	var z = Player.getPointedBlockZ();
	Level.dropItem(x,y+5,z,0,264,10);
	Level.dropItem(x-1,y+5,z,0,264,5);
	Level.dropItem(x-1,y+5,z+1,0,264,5);
	Level.dropItem(x,y+5,z-1,0,264,5);
	Level.dropItem(x,y+5,z+1,0,264,5);
	Level.dropItem(x-1,y+5,z-1,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5);
	Level.dropItem(x+1,y+5,z,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5); 
	Level.dropItem(x,y+5,z,0,264,10);
	Level.dropItem(x-1,y+5,z,0,264,5);
	Level.dropItem(x-1,y+5,z+1,0,264,5);
	Level.dropItem(x,y+5,z-1,0,264,5);
	Level.dropItem(x,y+5,z+1,0,264,5);
	Level.dropItem(x-1,y+5,z-1,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5);
	Level.dropItem(x+1,y+5,z,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5); 
	Level.dropItem(x,y+5,z,0,264,10);
	Level.dropItem(x-1,y+5,z,0,264,5);
	Level.dropItem(x-1,y+5,z+1,0,264,5);
	Level.dropItem(x,y+5,z-1,0,264,5);
	Level.dropItem(x,y+5,z+1,0,264,5);
	Level.dropItem(x-1,y+5,z-1,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5);
	Level.dropItem(x+1,y+5,z,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5); 
	Level.dropItem(x,y+5,z,0,264,10);
	Level.dropItem(x-1,y+5,z,0,264,5);
	Level.dropItem(x-1,y+5,z+1,0,264,5);
	Level.dropItem(x,y+5,z-1,0,264,5);
	Level.dropItem(x,y+5,z+1,0,264,5);
	Level.dropItem(x-1,y+5,z-1,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5);
	Level.dropItem(x+1,y+5,z,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5); 
	Level.dropItem(x,y+5,z,0,264,10);
	Level.dropItem(x-1,y+5,z,0,264,5);
	Level.dropItem(x-1,y+5,z+1,0,264,5);
	Level.dropItem(x,y+5,z-1,0,264,5);
	Level.dropItem(x,y+5,z+1,0,264,5);
	Level.dropItem(x-1,y+5,z-1,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5);
	Level.dropItem(x+1,y+5,z,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5);
      }
      }));
      menuLayout.addView(button);
            
      var button = new android.widget.Button(ctx);
      button.setText('Food');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addItemInventory(322, 64, 0);
      
      }
      }));
      menuLayout.addView(button);
      //More buttons...
      
      menu4 = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/3.5, ctx.getWindowManager().getDefaultDisplay().getHeight());
      menu4.setBackgroundDrawable(Color2);
      menu4.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.LEFT, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }
      
      
          function msMenu(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('Messages💬');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      
      var button = new android.widget.Button(ctx);
      button.setText('Exit');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu8.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Test Message');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("TEST");
      }
      }));
      menuLayout.addView(button);
      
          var button = new android.widget.Button(ctx);
      button.setText('Question');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§cWho are you?");
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Credit Card?');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§c May i have your §b Credit Card?");
      }
      }));
      menuLayout.addView(button);      
       
      var button = new android.widget.Button(ctx);
      button.setText('Recovery');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§aPhilipe8a mod menu BetaV1.2...");
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Question');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§aWant The Mod?");
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Co-Host');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§a$10 §cFor §9Co-§dHost...");
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Menu Name');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§aphilipe8a mod menu BetaV1.2...");
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Fake Derank');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§cDeranking please wait............................");
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Version Name');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§aBETAV1.2 PHILIPE8A MOD MENU...");
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Hi');
      button.setTextColor(android.graphics.Color.GREEN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("Hi");
      }
      }));
      menuLayout.addView(button);
      
      
      
      
      //More buttons...
      menu8 = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/3.5, ctx.getWindowManager().getDefaultDisplay().getHeight());
      menu8.setBackgroundDrawable(Color2);
      menu8.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }      
      
      function player2Menu(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('Client Options');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var button = new android.widget.Button(ctx);
      button.setText('Exit');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu00.dismiss();
      playerMenu();
      }
      }));
      menuLayout.addView(button);
      
      //More buttons...
      menu00 = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/3.5, ctx.getWindowManager().getDefaultDisplay().getHeight());
      menu00.setBackgroundDrawable(Color2);
      menu00.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.CENTER | android.view.Gravity.TOP, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }
      
      function fovMenu(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('Fov Options');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      
      var button = new android.widget.Button(ctx);
      button.setText('Exit');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu01.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);
      
          var button = new android.widget.Button(ctx);
      button.setText('Fov On');
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setFov(500)
      }
      }));
      menuLayout.addView(button);

       
      
      
         
    var button = new android.widget.Button(ctx);
      button.setText('Fov off');
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.resetFov();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('vision 1');
button.setTextColor(android.graphics.Color.GREEN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setFov(200)
          
         
      
      
      
      }
      }));
      
      
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('vision 2');
button.setTextColor(android.graphics.Color.GREEN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setFov(400)
          
         
      
      
      
      }
      }));
      
      
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('vision 3');
button.setTextColor(android.graphics.Color.GREEN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setFov(400)
          
         
      
      
      
      }
      }));
      
      
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('vision 4');
button.setTextColor(android.graphics.Color.GREEN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setFov(800)
          
         
      
      
      
      }
      }));
      
      
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('vision 5');
button.setTextColor(android.graphics.Color.GREEN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setFov(900)
          
         
      
      
      
      }
      }));
      
      
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('vision 6');
button.setTextColor(android.graphics.Color.GREEN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setFov(1400)
          
         
      
      
      
      }
      }));
      
      
      menuLayout.addView(button);
    
    var button = new android.widget.Button(ctx);
      button.setText('Fov RESET');
button.setTextColor(android.graphics.Color.GREEN);
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.resetFov()
          
         
      
      
      
      }
      }));
      
      
      menuLayout.addView(button);
      
      
      
      
      //More buttons...
      menu01 = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/3.5, ctx.getWindowManager().getDefaultDisplay().getHeight());
      menu01.setBackgroundDrawable(Color2);
      menu01.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.BOTTOM | android.view.Gravity.TOP, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }
      
       
      function exit(){
      var ctxe = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctxe.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var xLayout = new android.widget.LinearLayout(ctxe);
      var xButton = new android.widget.Button(ctxe);
      xButton.setText('EXT');
      xButton.setTextColor(android.graphics.Color.WHITE);
      xButton.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      exitUI.dismiss();
      menu.dismiss();
      }
      }));
      xLayout.addView(xButton);
      exitUI = new android.widget.PopupWindow(xLayout, dip2px(40), dip2px(40));
      exitUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      exitUI.showAtLocation(ctxe.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 0);
      }catch(exception){
      print(exception);
      }
      }}));
      }
      function leaveGame(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      if(GUI != null){
      GUI.dismiss();
      GUI = null;
      }
      if(menu != null){
      menu.dismiss();
      menu = null;
      }
      if(exitUI != null){
      exitUI.dismiss();
      exitUI = null;
      }
      }}));
      }

      
      function exit(){
      var ctxe = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctxe.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var xLayout = new android.widget.LinearLayout(ctxe);
      var xButton = new android.widget.Button(ctxe);
      xButton.setText('EXT');
      xButton.setTextColor(android.graphics.Color.WHITE);
      xButton.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      exitUI.dismiss();
      menu.dismiss();
      }
      }));
      xLayout.addView(xButton);
      exitUI = new android.widget.PopupWindow(xLayout, dip2px(0), dip2px(0));
      exitUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      exitUI.showAtLocation(ctxe.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, 0, 0);
      }catch(exception){
      print(exception);
      }
      }}));
      }
      function leaveGame(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      if(GUI != null){
      GUI.dismiss();
      GUI = null;
      }
      if(menu != null){
      menu.dismiss();
      menu = null;
      }
      if(exitUI != null){
      exitUI.dismiss();
      exitUI = null;
      }
      }}));
      }
