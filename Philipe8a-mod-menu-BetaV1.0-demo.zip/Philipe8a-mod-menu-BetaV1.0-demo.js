print ('Welcome To philipe8a mod')
print ('Made By philipe8a')
print ('Enjoy')
print ('Mod Menu Open...')
print ('90%')
print ('100%')

//Main Maker philipe8a
//Made by philipe8a [©Copyright 2019 All rights reserved.]
//Create by Philipe8a
//Thank You
//philipe8a
//<>--------------------<>
//Youtube Creator: Philipe8a
//<>--------------------<>


var GUI;
      var menu;
      var exitUI;
      
      
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
var Button = android.widget.Button;
var LinearLayout = android.widget.LinearLayout;
var RelativeLayout = android.widget.RelativeLayout;
var PopupWindow = android.widget.PopupWindow;
var ScrollView = android.widget.ScrollView;
var TextView = android.widget.TextView;
var CheckBox = android.widget.CheckBox;
var Switch = android.widget.Switch;
var Toast = android.widget.Toast;
var Runnable = java.lang.Runnable;
var View = android.view.View;
var ColorDrawable = android.graphics.drawable.ColorDrawable;
var Color = android.graphics.Color;
var Gravity = android.view.Gravity;
var Intent = android.content.Intent;
var Uri = android.net.Uri;
var NamePlayer = Player.getName(Player.getEntity());
var numbers = android.text.InputType.TYPE_CLASS_NUMBER;
var number = android.text.InputType.TYPE_NUMBER_FLAG_SIGNED;

      function dip2px(dips){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      return Math.ceil(dips * ctx.getResources().getDisplayMetrics().density);
      }
      function newLevel(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var layout = new android.widget.LinearLayout(ctx);
      layout.setOrientation(1);
      var menuBtn = new android.widget.Button(ctx);
      menuBtn.setText('Menu Philipe8a<3');
      menuBtn.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      mainMenu();
      exit();
      }
      }));
      layout.addView(menuBtn);
      GUI = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
      GUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.BLUE));
      GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 10, 20);
      }catch(err){
      print('An error occured: ' + err);
      }
      }}));
      }
       function mainMenu(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var menuLayout = new android.widget.LinearLayout(ctx);
      var menuScroll = new android.widget.ScrollView(ctx);
      var menuLayout1 = new android.widget.LinearLayout(ctx);
      menuLayout.setOrientation(1);
      menuLayout1.setOrientation(1);
      menuScroll.addView(menuLayout);
      menuLayout1.addView(menuScroll);
      var button = new android.widget.Button(ctx);
      button.setText('<<<<=========Mod menu philipe8a=========>>>>');
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("Menu Opened At  " + Math.floor(Player.getX()) + " y: " + Math.floor(Player.getY() - 1) + " z: " + Math.floor(Player.getZ()));
      }
      }));
      menuLayout.addView(button);  
    
      var scrollText = new android.widget.TextView(ctx);
scrollText.setText("WELCOME TO PHILIPE8A MOD MENU VBeta 1 Menu");
scrollText.setTextSize(15);         
scrollText.setTextColor(android.graphics.Color.CYAN);    
 scrollText.setGravity(android.view.Gravity.CENTER);
scrollText.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
scrollText.setMarqueeRepeatLimit(-2);
scrollText.setSingleLine();
scrollText.setHorizontallyScrolling(true);
scrollText.setSelected(true);
menuLayout.addView (scrollText);



var buttonS = new android.widget.Button(ctx);
            buttonS.setText("YOUTUBE CHANNEL");
            buttonS.setTextColor(android.graphics.Color.BLUE);   
            buttonS.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));       
            buttonS.setTextSize(20);           
            buttonS.setWidth(70);
            buttonS.setHeight(50);            
            buttonS.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    menu.dismiss();
                     sjbutton();   
android.widget.Toast.makeText(ctx,"Opening the URL...",0).show();
						var intentBrowser = new android.content.Intent(ctx);
						intentBrowser.setAction(android.content.Intent.ACTION_VIEW);
						intentBrowser.setData(android.net.Uri.parse("https://www.youtube.com/channel/UCthHfOUq80-zS_MeOdgWLfQ"));
	ctx.startActivity(intentBrowser)       
              }
            }));
            menuLayout.addView(buttonS);
   


    var button = new android.widget.Button(ctx);
      button.setText('Click Inject Games!');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
          ModPE.setGameSpeed(110);
          Player.setCanFly(1)
          Player.isFlying(1)
          ModPE.setFov(98)
          ModPE.log(0)
          print('CulticClient Importing Injection...')
          print('CulticClient Registering Scripts...')
          print('CulticClient Verified Activating Injection!')
          print('CulticClient Injection! Complete!')
          clientMessage('§cGAME BEING §aINJECTED!!') 
          }
          }));
          menuLayout.addView(button);         
          
          
          
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('�Main Menu�');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(20);
      textview.setText('(=====================)');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var button = new android.widget.Button(ctx);
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu12.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);
      
       
      var button = new android.widget.Button(ctx);
      button.setText('Fly On');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage ('Fly On')	
      Player.setCanFly(1);
      }
      }));
      menuLayout.addView(button);
      
       
      var button = new android.widget.Button(ctx);
      button.setText('Fly Off');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Fly Off')	
      Player.setCanFly(2);
      }
      }));
      menuLayout.addView(button);
      
       
      var button = new android.widget.Button(ctx);
      button.setText('Insane Speed');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setGameSpeed(3000)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Normal Speed');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setGameSpeed(20)
      }
      }));
      menuLayout.addView(button);     
      
      
      
      var button = new android.widget.Button(ctx);
      button.setText('Sharpness');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      (Player.enchant(Player.getSelectedSlotId(), Enchantment.SHARPNESS, 100));
      }
      }));
      menuLayout.addView(button);
      
      
      
            var button = new android.widget.Button(ctx);
      button.setText('Critical Trail');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Level.addParticle(ParticleType.crit, getPlayerX(), getPlayerY(), getPlayerZ(), 0, 0, 0, 10)
      }
      }));
      menuLayout.addView(button);
      
      
           
      var button = new android.widget.Button(ctx);
      button.setText('Lite Boost');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      setVelX( getPlayerEnt(), 3)
      }
      }));
      menuLayout.addView(button);
      
      
      
      var button = new android.widget.Button(ctx);
      button.setText('Heavy Boost');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
       setVelX( getPlayerEnt(), 7)
      }
      }));
      menuLayout.addView(button);
     
     
        
      var button = new android.widget.Button(ctx);
      button.setText('Heal');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.setHealth(20)
      }
      }));
      menuLayout.addView(button);
      
       
             
var button = new android.widget.Button(ctx);
      button.setText('God Mode');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.setHealth(9099999)
      }
      }));
      menuLayout.addView(button);
      
      
      
      var button = new android.widget.Button(ctx);
      button.setText('KYS');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.setHealth(0)
      }
      }));
      menuLayout.addView(button);


 
      var button = new android.widget.Button(ctx);
      button.setText('NUKE');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){	
      lientMessage ('Nuke!')
      explode(getPlayerX(),getPlayerY(),getPlayerZ(),15);
      }
      }));
      menuLayout.addView(button);
      
      
      
var button = new android.widget.Button(ctx);
      button.setText('Superjump On');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
 	 lientMessage ('Super Jump On')
      Entity.addEffect(Player.getEntity (),MobEffect.jump,999999,2,false,false);
      }
      }));
      menuLayout.addView(button);
      
       
      var button = new android.widget.Button(ctx);
      button.setText('Superjump Off');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Super Jump Off')	
      Entity.removeAllEffects (getPlayerEnt ());
      }
      }));
      menuLayout.addView(button);



var button = new android.widget.Button(ctx);
      button.setText('Pro Mode On');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Pro Mode On')	
      ModPE.setFov (120)
      }
      }));
      menuLayout.addView(button);
      
       
      var button = new android.widget.Button(ctx);
      button.setText('Pro Mode Off');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Pro Mode Off')		
      ModPE.setFov (70)
      }
      }));
      menuLayout.addView(button);



var button = new android.widget.Button(ctx);
      button.setText('Noclip On');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Noclip On')		
      Entity.setCollisionSize(getPlayerEnt(), 0.0, 0.0);
      }
      }));
      menuLayout.addView(button);
      
       
      var button = new android.widget.Button(ctx);
      button.setText('Noclip Off');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){	
      lientMessage ('Noclip Off')
      Player.setHealth(0)
      }
      }));
      menuLayout.addView(button);
      
      
      
      var button = new android.widget.Button(ctx);
      button.setText('Instant Mine On');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Instant Mine On')	
      Entity.addEffect(Player.getEntity(),MobEffect.digSpeed,999999,200,false,false);
      }
      }));
      menuLayout.addView(button);
      
       
      var button = new android.widget.Button(ctx);
      button.setText('Instant Mine Off');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Instant Mine Off')	
      Entity.removeAllEffects (getPlayerEnt ());
      }
      }));
      menuLayout.addView(button);
      
      
      
        var button = new android.widget.Button(ctx);
      button.setText('Invis On');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Invis On')	
      Entity.addEffect(Player.getEntity(), MobEffect.invisibility, 999999, 2, false, false);
      }
      }));
      menuLayout.addView(button);
      
       
      var button = new android.widget.Button(ctx);
      button.setText('Invis Off');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
 	 lientMessage ('Invis Off')
      Entity.removeAllEffects (getPlayetEnt ());
      }
      }));
      menuLayout.addView(button);
      
      
      
       var button = new android.widget.Button(ctx);
      button.setText('Pause');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
 	 lientMessage ('Pause')
      ModPE.setGameSpeed(0)
      }
      }));
      menuLayout.addView(button);
      
       
      var button = new android.widget.Button(ctx);
      button.setText('Resume');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Resume')
      ModPE.setGameSpeed(20)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Give Food');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addItemInventory(322, 64, 0);
      }
      }));
      menuLayout.addView(button);  
 
   
            
          var button = new android.widget.Button(ctx);
      button.setText('Day');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Level.setTime (10000)
      }
      }));
      menuLayout.addView(button);
      
      
 
      var button = new android.widget.Button(ctx);
      button.setText('Night');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Level.setTime (18000)
      }
      }));
      menuLayout.addView(button);
      
            
             
      var button = new android.widget.Button(ctx);
      button.setText('Hitbox On');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Hitbox On')	
      Entity.setCollisionSize(Player.getPointedEntity(),10,10);
      }
      }));
      menuLayout.addView(button);
      
       
      var button = new android.widget.Button(ctx);
      button.setText('Hitbox Off');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Hitbox Off')
      Entity.setCollisionSize(Player.getPointedEntity(),1,2);
      }
      }));
      menuLayout.addView(button);
  
  
  
     var button = new android.widget.Button(ctx);
      button.setText('Coordinates');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("Your Coordinates Are " + Math.floor(Player.getX()) + " y: " + Math.floor(Player.getY() - 1) + " z: " + Math.floor(Player.getZ()));
      }
      }));
      menuLayout.addView(button);  
 
 
 
 
             var button = new android.widget.Button(ctx);
      button.setText('Creative');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){	
      Level.setGameMode(0)
      }
      }));
      menuLayout.addView(button); 
  
  
  
  
             var button = new android.widget.Button(ctx);
      button.setText('Survival');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){	
      Level.setGameMode(1)
      }
      }));
      menuLayout.addView(button);    
      
      
      
      var button = new android.widget.Button(ctx);
      button.setText('Add Xp');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addExp(999999)
      }
      }));
      menuLayout.addView(button); 
      
 
      
         var button = new android.widget.Button(ctx);
      button.setText('Rocket');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      setVelY(getPlayerEnt(),6);
      }
      }));
      menuLayout.addView(button); 
      
      
      
      var button = new android.widget.Button(ctx);
      button.setText('Super Rocket');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      setVelY( getPlayerEnt(), 25)
      }
      }));
      menuLayout.addView(button);
      
      
      
      var button = new android.widget.Button(ctx);
      button.setText('explode');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('BOOM!!!!')	
      explode (getPlayerX(),getPlayerY(),getPlayerZ(),10)
      }
      }));
      menuLayout.addView(button);
      
      
      
      var button = new android.widget.Button(ctx);
      button.setText('FullBrigh');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Entity.addEffect(Player.getEntity(),MobEffect.nightVision,99999,100,false,false);
      }
      }));
      menuLayout.addView(button);
  
  
 
var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('🔰Armor🔰');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(20);
      textview.setText('(=====================)');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var button = new android.widget.Button(ctx);
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu12.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);
      
      
           var button = new android.widget.Button(ctx);
      button.setText('Diamond Armor');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.setArmorSlot (0,310,0);
      Player.setArmorSlot (1,311,0);
      Player.setArmorSlot (2,312,0);
      Player.setArmorSlot (3,313,0);
      }
      }));
      menuLayout.addView(button); 
      
      
      
      var button = new android.widget.Button(ctx);
      button.setText('Gold Armor');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.setArmorSlot (0,314,0);
      Player.setArmorSlot (1,315,0);
      Player.setArmorSlot (2,316,0);
      Player.setArmorSlot (3,317,0);
      }
      }));
      menuLayout.addView(button); 
      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('Tools🔧');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(20);
      textview.setText('(=====================)');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var button = new android.widget.Button(ctx);
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu12.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);
      
      
      var button = new android.widget.Button(ctx);
      button.setText('Diamond Tools');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addItemInventory(276, 1, 0);
      Player.addItemInventory(277, 1, 0);
      Player.addItemInventory(278, 1, 0);
      Player.addItemInven
      }
      }));
      menuLayout.addView(button); 
      
      
      
      var button = new android.widget.Button(ctx);
      button.setText('Gold Tools');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      Player.addItemInventory(283, 1, 0);
      Player.addItemInventory(284, 1, 0);
      Player.addItemInventory(285, 1, 0);
      Player.addItemInventory(286, 1, 0);
      }
      }));
      menuLayout.addView(button); 
      
      
      
      var button = new android.widget.Button(ctx);
      button.setText('Diamonds dropped');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      var x = Player.getPointedBlockX();
	var y = Player.getPointedBlockY()+1;
	var z = Player.getPointedBlockZ();
	Level.dropItem(x,y+5,z,0,264,10);
	Level.dropItem(x-1,y+5,z,0,264,5);
	Level.dropItem(x-1,y+5,z+1,0,264,5);
	Level.dropItem(x,y+5,z-1,0,264,5);
	Level.dropItem(x,y+5,z+1,0,264,5);
	Level.dropItem(x-1,y+5,z-1,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5);
	Level.dropItem(x+1,y+5,z,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5); 
	Level.dropItem(x,y+5,z,0,264,10);
	Level.dropItem(x-1,y+5,z,0,264,5);
	Level.dropItem(x-1,y+5,z+1,0,264,5);
	Level.dropItem(x,y+5,z-1,0,264,5);
	Level.dropItem(x,y+5,z+1,0,264,5);
	Level.dropItem(x-1,y+5,z-1,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5);
	Level.dropItem(x+1,y+5,z,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5); 
	Level.dropItem(x,y+5,z,0,264,10);
	Level.dropItem(x-1,y+5,z,0,264,5);
	Level.dropItem(x-1,y+5,z+1,0,264,5);
	Level.dropItem(x,y+5,z-1,0,264,5);
	Level.dropItem(x,y+5,z+1,0,264,5);
	Level.dropItem(x-1,y+5,z-1,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5);
	Level.dropItem(x+1,y+5,z,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5); 
	Level.dropItem(x,y+5,z,0,264,10);
	Level.dropItem(x-1,y+5,z,0,264,5);
	Level.dropItem(x-1,y+5,z+1,0,264,5);
	Level.dropItem(x,y+5,z-1,0,264,5);
	Level.dropItem(x,y+5,z+1,0,264,5);
	Level.dropItem(x-1,y+5,z-1,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5);
	Level.dropItem(x+1,y+5,z,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5); 
	Level.dropItem(x,y+5,z,0,264,10);
	Level.dropItem(x-1,y+5,z,0,264,5);
	Level.dropItem(x-1,y+5,z+1,0,264,5);
	Level.dropItem(x,y+5,z-1,0,264,5);
	Level.dropItem(x,y+5,z+1,0,264,5);
	Level.dropItem(x-1,y+5,z-1,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5);
	Level.dropItem(x+1,y+5,z,0,264,5);
	Level.dropItem(x+1,y+5,z+1,0,264,5);
      }
      }));
      menuLayout.addView(button);
      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('Vision');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(20);
      textview.setText('(=====================)');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var button = new android.widget.Button(ctx);
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu12.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);
      
         var button = new android.widget.Button(ctx);
      button.setText('Vision 1');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setFov(50)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Vision 2');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setFov(100)
      }
      }));
      menuLayout.addView(button);
      
     var button = new android.widget.Button(ctx);
      button.setText('Vision 3');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setFov(200)
      }
      }));
      menuLayout.addView(button); 
      
      var button = new android.widget.Button(ctx);
      button.setText('Vision 4');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setFov(400)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Vision 5');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setFov(800)
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Visions Reset');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.resetFov()
      }
      }));
      menuLayout.addView(button);
      
      
      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('The Time Speed');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(20);
      textview.setText('(=====================)');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var button = new android.widget.Button(ctx);
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu12.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Slow Motion');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setGameSpeed(6);
      }
      }));
      menuLayout.addView(button);
      
      
      
      var button = new android.widget.Button(ctx);
      button.setText('Normal Speed');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      ModPE.setGameSpeed(20);
      }
      }));
      menuLayout.addView(button);
      
    

     var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('Player (Co-Host)');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(20);
      textview.setText('(=====================)');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var button = new android.widget.Button(ctx);
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu12.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);

     var button = new android.widget.Button(ctx);
      button.setText("Player 1 (Host)");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      player2Menu();
      menu0.dismiss();
      }
      }));
      menuLayout.addView(button);
  
  
          
      var button = new android.widget.Button(ctx);
      button.setText("Player 2");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      player2Menu();
      menu0.dismiss();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("Player 3");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      player2Menu();
      menu0.dismiss();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("Player 4");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      player2Menu();
      menu0.dismiss();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("Player 5");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      player2Menu();
      menu0.dismiss();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("Player 6");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      player2Menu();
      menu0.dismiss();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("Player 7");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      player2Menu();
      menu0.dismiss();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("Player 8");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      player2Menu();
      menu0.dismiss();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("Player 9");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      player2Menu();
      menu0.dismiss();
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText("Player 10");
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      player2Menu();
      menu0.dismiss();
      }
      }));
      menuLayout.addView(button);
      
      
      
       var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('�Building Menu�');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(20);
      textview.setText('(=====================)');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var button = new android.widget.Button(ctx);
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu12.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);
      
        var button = new android.widget.Button(ctx);
      button.setText('Build Home');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Home building please wait...')	
              homeX = Player.getX();
              homeY = Player.getY()+2;
              homeZ = Player.getZ();
              sethome = 1;
      }
      }));
      menuLayout.addView(button);
      
      
      
         var button = new android.widget.Button(ctx);
      button.setText('Build Tower');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      lientMessage ('Tower building please wait...')	
      setVely(getPlayerEnt(),0.65);
      }
      }));
      menuLayout.addView(button); 
  

      
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('�Mesages Menu�');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(20);
      textview.setText('(=====================)');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var button = new android.widget.Button(ctx);
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu12.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);   
      
      var button = new android.widget.Button(ctx);
      button.setText('Recovery Service');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§a$10 §cFor §eRecovery §9PayPal §cONLY!");
      }
      }));
      menuLayout.addView(button);
      
      
      var button = new android.widget.Button(ctx);
      button.setText('Co-Host Service');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§a$10 §cFor §Co-Host §9PayPal §cONLY!");
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Your Host');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§a$'+player 1+' is your host!");
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Fake Derank');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§cDeranking please wait............................Sike §aN*igga §eYou §bFell §dFor §cIt!");
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Players do Drugs');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§cAll of you §eF*ggots §bDo §aDrugs!");
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Credit Card?');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§c May i have your §b Credit Card?");
      }
      }));
      menuLayout.addView(button);
      
      var button = new android.widget.Button(ctx);
      button.setText('Creator');
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      clientMessage("§c The creator is philipe8a SUBCRIBE to Yt/Philipe8a");
      }
      }));
      menuLayout.addView(button);
      


             var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('�MORE MODS COMING UP�');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(20);
      textview.setText('(=====================)');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var button = new android.widget.Button(ctx);
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu12.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);   


  
           var textview = new android.widget.TextView(ctx);
      textview.setTextSize(40);
      textview.setText('🔱THE MOD CREATE BY Philipe8a🔱');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var textview = new android.widget.TextView(ctx);
      textview.setTextSize(20);
      textview.setText('(=====================)');
      textview.setTextColor(android.graphics.Color.CYAN);
      textview.setGravity(android.view.Gravity.CENTER);
      menuLayout.addView(textview);
      var button = new android.widget.Button(ctx);
      button.setTextColor(android.graphics.Color.CYAN);
      button.setTextSize(20)
      button.setGravity(android.view.Gravity.LEFT);
      button.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      button.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      menu12.dismiss();
      mainMenu();
      }
      }));
      menuLayout.addView(button);   
      
      var colorview = new android.widget.TextView(ctx);
      colorview.setText('philipe8a');
      colorview.setTextSize(24);
      colorview.setTextColor(android.graphics.Color.parseColor('#00FF5C'));
   
      menu = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/3.5, ctx.getWindowManager().getDefaultDisplay().getHeight());
      menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.GREEN));
      menu.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 0, 0);
      }catch(error){
      print('An error occured: ' + error);
      }
      }}));
      }
      function exit(){
      var ctxe = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctxe.runOnUiThread(new java.lang.Runnable({ run: function(){
      try{
      var xLayout = new android.widget.LinearLayout(ctxe);
      var xButton = new android.widget.Button(ctxe);
      xButton.setText('EXT');
      xButton.setTextColor(android.graphics.Color.RED);
      xButton.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      exitUI.dismiss();
      menu.dismiss();
      }
      }));
      xLayout.addView(xButton);
      exitUI = new android.widget.PopupWindow(xLayout, dip2px(40), dip2px(40));
      exitUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
      exitUI.showAtLocation(ctxe.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 0);
      }catch(exception){
      print(exception);
      }
      }}));
      }
      function leaveGame(){
      var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
      ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
      if(GUI != null){
      GUI.dismiss();
      GUI = null;
      }
      if(menu != null){
      menu.dismiss();
      menu = null;
      }
      if(exitUI != null){
      exitUI.dismiss();
      exitUI = null;
      }
      }}));
      }
